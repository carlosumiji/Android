package br.com.fiap.nac02.RM78909;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SorveteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sorvete);
    }
}
